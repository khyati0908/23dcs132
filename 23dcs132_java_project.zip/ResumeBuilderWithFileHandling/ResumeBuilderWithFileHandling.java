import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ResumeBuilderWithFileHandling {

    public static void main(String[] args) {
        // Create a scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Collect user information
        System.out.print("Enter your Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your Email: ");
        String email = scanner.nextLine();

        System.out.print("Enter your Phone Number: ");
        String phone = scanner.nextLine();

        System.out.print("Enter your Address: ");
        String address = scanner.nextLine();

        System.out.print("Enter your Degree: ");
        String degree = scanner.nextLine();

        System.out.print("Enter your University: ");
        String university = scanner.nextLine();

        System.out.print("Enter your Graduation Year: ");
        String year = scanner.nextLine();

        System.out.print("Enter your GPA/Marks: ");
        String gpa = scanner.nextLine();

        System.out.print("Enter your Job Title: ");
        String jobTitle = scanner.nextLine();

        System.out.print("Enter your Company Name: ");
        String company = scanner.nextLine();

        System.out.print("Enter the Duration of Employment: ");
        String duration = scanner.nextLine();

        System.out.print("Enter a Description of your Work Experience: ");
        String workDescription = scanner.nextLine();

        System.out.print("Enter your Skills (comma-separated): ");
        String skills = scanner.nextLine();

        // Call the method to write the resume data to a file
        writeResumeToFile(name, email, phone, address, degree, university, year, gpa, jobTitle, company, duration, workDescription, skills);

        // Close the scanner
        scanner.close();
    }

    // Method to write the resume to a text file
    public static void writeResumeToFile(String name, String email, String phone, String address, String degree, 
                                         String university, String year, String gpa, String jobTitle, 
                                         String company, String duration, String workDescription, String skills) {
        try {
            // Create a FileWriter to write the resume details into a file named "Resume.txt"
            FileWriter writer = new FileWriter("Resume.txt");

            // Write the resume details in a structured format
            writer.write("Resume\n");
            writer.write("-------\n");
            writer.write("Name: " + name + "\n");
            writer.write("Email: " + email + "\n");
            writer.write("Phone: " + phone + "\n");
            writer.write("Address: " + address + "\n\n");

            writer.write("Education\n");
            writer.write("---------\n");
            writer.write("Degree: " + degree + "\n");
            writer.write("University: " + university + "\n");
            writer.write("Graduation Year: " + year + "\n");
            writer.write("GPA/Marks: " + gpa + "\n\n");

            writer.write("Work Experience\n");
            writer.write("---------------\n");
            writer.write("Job Title: " + jobTitle + "\n");
            writer.write("Company: " + company + "\n");
            writer.write("Duration: " + duration + "\n");
            writer.write("Description: " + workDescription + "\n\n");

            writer.write("Skills\n");
            writer.write("------\n");
            writer.write("Skills: " + skills + "\n");

            // Close the file writer after writing all data
            writer.close();

            // Notify the user that the resume has been generated successfully
            System.out.println("Resume generated successfully in 'Resume.txt'!");

        } catch (IOException e) {
            // Print the exception if an error occurs during file writing
            System.out.println("An error occurred while generating the resume.");
            e.printStackTrace();
        }
    }
}